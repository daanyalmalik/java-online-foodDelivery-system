package BusinessLogic.Controller;

import BusinessLogic.FoodChain.FoodChainProfile;
import BusinessLogic.FoodChain.ListofFoodItems;
import BusinessLogic.Order.Order;
import BusinessLogic.User.Customer;
import BusinessLogic.User.SystemAdministrator;
import DataAccess.ORMapper;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;

import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author Rija Fahi
 * 
 * */
public class Controller extends Application
{
    /*Singleton objects */
    public static ListofFoodItems DB_FoodItems = ListofFoodItems.getInstance();
    public static ORMapper DB_OR = ORMapper.getInstance();
    public static Order the_Order;
    public static FoodChainProfile selected_FoodChain;
    
    @Override
    public void start(Stage stage) throws Exception 
    {
        Parent root = FXMLLoader.load(getClass().getResource("/Presentation/FXML/LoginScreen.fxml"));
        Scene scene = new Scene(root, 640,480);
        stage.setTitle("FoodExpress");
        stage.setScene(scene);
        stage.show();
    }
    public static void main(String[] args) {
        launch(args);
    }
    
}

