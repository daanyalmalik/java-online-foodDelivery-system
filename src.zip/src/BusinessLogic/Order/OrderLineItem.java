package BusinessLogic.Order;
/**
 *
 * @author daany
 */
public class OrderLineItem {
    public String id;
    public String foodID;
    public String price;
    public String quantity;
    
    
}
