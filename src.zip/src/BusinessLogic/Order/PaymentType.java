package BusinessLogic.Order;

public class PaymentType {
    
    public String description;
    public String PaymentID;

    
}
