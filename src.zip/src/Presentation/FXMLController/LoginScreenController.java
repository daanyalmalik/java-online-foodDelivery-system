/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.FXMLController;
import BusinessLogic.Controller.Controller;
import BusinessLogic.User.User;
import com.jfoenix.controls.JFXButton;

import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 *
 * @author daany
 */
public class LoginScreenController implements Initializable {
 
    
    @FXML
    private JFXTextField password;

    @FXML
    private JFXTextField username;
    
    
    @FXML
    private JFXButton signup;

    @FXML
    void makelogin(ActionEvent event) throws SQLException, IOException 
    {
        
        String uname = username.getText();
        String pass =  password.getText();
        User U1 = new User();
        String authenticated = U1.ReadUserInfo(uname, pass);
        System.out.println(authenticated + "entered!");
        Parent home_page = FXMLLoader.load(getClass().getResource("/Presentation/FXML/OrderNowScreen.fxml"));
        String temp = home_page.toString();
        Scene home_page_scene = new Scene(home_page, 640, 480);
        Stage S1 = (Stage)((Node)event.getSource()).getScene().getWindow();
        S1.setTitle("FoodExpress");
        S1.setScene(home_page_scene);
        S1.show();
        
    } 
    
    @FXML
    void RegisterUser(ActionEvent event) throws IOException 
    {
        Parent home_page = FXMLLoader.load(getClass().getResource("/Presentation/FXML/Registeration.fxml"));
        String temp = home_page.toString();
        Scene home_page_scene = new Scene(home_page);
        Stage S1 = (Stage)((Node)event.getSource()).getScene().getWindow();
        S1.setScene(home_page_scene);
        S1.show();
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        username.setStyle("-fx-text-inner-color: white;");
        password.setStyle("-fx-text-inner-color: white;");
    }    
    
}
