/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.FXMLController;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Rija Fahim
 */
public class BrowseFoodController implements Initializable {
 @FXML
    private Button bbq;

    @FXML
    private Button pizza;

    @FXML
    private Button bakery;

    @FXML
    private TextField serach;

    @FXML
    private Button coffee;

    @FXML
    private Button go;

    @FXML
    private Button fastfood;

    @FXML
    void getResteraunts(ActionEvent event) {

    }

    @FXML
    void FastFood(ActionEvent event) {

    }

    @FXML
    void CoffeeHouse(ActionEvent event) {

    }

    @FXML
    void Bakeries(ActionEvent event) {

    }

    @FXML
    void Pizzas(ActionEvent event) {

    }

    @FXML
    void BBQS(ActionEvent event) {

    }

    @FXML
    void goButton(ActionEvent event) {

    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
